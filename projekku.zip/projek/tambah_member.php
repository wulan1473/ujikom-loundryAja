<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>halaman tambah member</title>

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <style>
    body{
        background: #eee;
    }
    .form-login{
        margin-top: 13%;
        margin-left: 30%;
    }
    .outer-form-login{
        padding: 20px;
        background: #eeeeee;
        position: relative;
        border-radius: 5px;
    }

    .inner-login .form-control{
        background: #D3d3d3;
    }
    h3.title-login{
        font-size: 20px;
        margin-bottom: 20px;
    }
    .btn-custom-green{
        background:#21a957;
        color:#fff;
    }

        
    </style>
</head>
<body>
<div class="col-md-4 col-md-offset-4 form-login">
    <div class="outter-form-login">

        <form action="proses_/proses_tambah_member.php" class="inner-login" method="POST">
        <h3 class="text-center title-login">Tambah Member</h3>
            <div class="form-group">
                <input type="text" class="form-control" name="nama" placeholder="Nama" required>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="alamat" placeholder="Alamat" required>
            </div>
            <div class="form-group">
                <select name="jenis_kelamin" class="form-control" >
                    <option  value="L" class="form-control">Laki laki</option>
                    <option  value="P" class="form-control">Perempuan </option>
                </select>
            </div>
            <div class="form-group">
                <input type="number" class="form-control" name="telepon" placeholder="Nomor Telpon" required>
            </div>
                <input type="submit" class="btn btn-block btn-custom-green" value="Tambah">
        </form>
    </div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>