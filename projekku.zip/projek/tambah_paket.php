<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>halaman tambah outlet</title>

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <style>
    body{
        background: #eee;
    }
    .form-login{
        margin-top: 13%;
        margin-left: 30%;
    }
    .outer-form-login{
        padding: 20px;
        background: #eeeeee;
        position: relative;
        border-radius: 5px;
    }

    .inner-login .form-control{
        background: #D3d3d3;
    }
    h3.title-login{
        font-size: 20px;
        margin-bottom: 20px;
    }
    .btn-custom-green{
        background:#21a957;
        color:#fff;
    }

        
    </style>
</head>
<body>
<div class="col-md-4 col-md-offset-4 form-login">
    <div class="outter-form-login">

        <form action="proses_/proses_tambah_paket.php" class="inner-login" method="POST">
        <h3 class="text-center title-login">Tambah paket</h3>
            <div class="form-group">
                <select name="id_outlet" class="form-group">
                    <?php
                    include "db.php";
                    $db = new Database();
                    $outlet = $db->getAll('outlet');
                    foreach($outlet as $o):
                    ?>
                        <option value="<?php echo $o['id_outlet']; ?>"> <?php echo $o['nama']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <select name="jenis" class="form-group">
                    <option value="kiloan">Kiloan</option>
                    <option value="selimut">Selimut</option>
                    <option value="bed cover">Bed cover</option>
                    <option value="kaos">Kaos</option>
                    <option value="lain-lain">Lain-lain</option>
                </select>
            </div>
            <div class="form-group">
                <input type="text" class="form-control" name="nama_paket" placeholder="Nama Paket" required>
            </div>
            <div class="form-group">
                <input type="number" class="form-control" name="harga" placeholder="Harga Paket" required>
            </div>
                <input type="submit" class="btn btn-block btn-custom-green" value="Tambah">
        </form>
    </div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>