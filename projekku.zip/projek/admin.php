<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <style>
    body{
        background: #eee;
    }
    .site-footer{
        background:#26272b;
        padding:45px 0 20px;
        font-size:15px;
        line-height:24px;
        color:#737373;
    }
    .site-footer hr{
        border-top-color:#bbb;
        opacity:0.5;
    }
    .site-footer hr.small{
        margin:20px;
    }
    .site-fppter h6{
        color:#fff;
        font-size:16px;
        text-transform:uppercase;
        margin-top:5px;
        letter-spacing:2px;
    }
    
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
    <div class="container">
        <a class="navbar-brand" href="#">
            <img src="" alt="">
        </a>]
    <button class="navbar-toggler" tyoe="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="navigation">
        <span class="navbar-toggle-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a href="" class="nav-link">Home
                    <span class="sr-only">(current)</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="member.php" class="nav-link">Member</a>
            </li>
            <li class="nav-item">
                <a href="outlet.php" class="nav-link">Outlet</a>
            </li>
            <li class="nav-item">
                <a href="paket.php" class="nav-link">Paket</a>
            </li>
        </ul>
        </div>
    </div>
</nav>
  
<footer class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-6">
                <h6>Kami</h6>
                <p class="text-justify">Memberikan selalu layanan yang paling terbaik dan terjamin akan kebersihan pakaian, atau barang Anda.</p>
            </div>
            <div class="col-xs-6 col-md-3">
                <h6>Pathner kami</h6>
                <ul class="footer-links">
                    <li>Laundry Nirwan</li>
                    <li>Laundry Pebi</li>
                    <li>Laundry Wulan</li>
                    <li>Laundry Nur</li>
                </ul>
            </div>
            <div class="col-xs-6 col-md-3">
                <ul class="footer-links">
                    <li>Laundry Reksi</li>
                    <li>Laundry Akbar</li>
                    <li>Laundry Dini</li>
                    <li>Laundry Agustin</li>
                    <li>Laundry Hamzah</li>
                </ul>
            </div>
        </div>
        <hr>
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6 col-xs-12">
                    <p class="copyright-text">Copyright&copy; 2020 Allrights Reserved By <a href="index.php">Angkatan 2020</a></p>
                </div>
            </div>
        </div>
    </div>
</footer>
</body>
</html>