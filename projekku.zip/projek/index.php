<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <title> Selamat Datang | Customer </title>
    <link rel="stylesheet" href="fonts1/icomoon/style.css">  
    <link rel="stylesheet" href="css1/bootstrap.min.css">
    <link rel="stylesheet" href="css1/jquery-ui.css">
    <link rel="stylesheet" href="css1/owl.carousel.min.css">
    <link rel="stylesheet" href="css1/owl.theme.default.min.css">
    <link rel="stylesheet" href="css1/owl.theme.default.min.css">
    <link rel="stylesheet" href="css1/jquery.fancybox.min.css">
    <link rel="stylesheet" href="css1/bootstrap-datepicker.css">
    <link rel="stylesheet" href="fonts1/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css1/aos.css">
    <link rel="stylesheet" href="css1/style.css">
    <style>
      .card-body{
          height: 10cm;
          background-color: #26272b;
          color: white;
          padding: 100px;
          border-radius: 10px;
          font-family: 'Quicksand', sans-serif; 
          }
      .site-footer{
          background:#26272b;
          padding:45px 0 20px;
          font-size:15px;
          line-height:24px;
          border-radius: 10px;
          color:#white;
          }
      .site-footer hr{
          border-top-color:#bbb;
          opacity:0.5;
          }
      .site-footer hr.small{
          margin:20px;
          }
      .site-fppter h6{
          color:#fff;
          font-size:16px;
          text-transform:uppercase;
          margin-top:5px;
          letter-spacing:2px;
          }
    </style>
</head>
<body class="body">
  <div class="card text-center">
    <div class="card-body">
        <h2 class="card-title"> GO LAUNDRY </h2> <br>
        <h4 class="card-text"> Selamat Datang di Outlet Laundry Terpercaya dan Terbesar di Jawa Barat </h4> <br>
        <a href="login.php" class="btn btn-primary"> GET STARTED </a>
    </div>
  </div>
  <footer class="site-footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-6">
                <h6>Kami</h6>
                <p class="text-justify">Memberikan selalu layanan yang paling terbaik dan terjamin akan kebersihan pakaian, atau barang Anda.</p>
            </div>
            <div class="col-xs-6 col-md-3">
                <h6>Pathner kami</h6>
                <ul class="footer-links">
                    <li>Laundry Nirwan</li>
                    <li>Laundry Pebi</li>
                    <li>Laundry Wulan</li>
                    <li>Laundry Nur</li>
                </ul>
            </div>
            <div class="col-xs-6 col-md-3">
                <ul class="footer-links">
                    <li>Laundry Reksi</li>
                    <li>Laundry Akbar</li>
                    <li>Laundry Dini</li>
                    <li>Laundry Agustin</li>
                    <li>Laundry Hamzah</li>
                </ul>
            </div>
        </div>
        <hr>
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6 col-xs-12">
                    <p class="copyright-text">Copyright&copy; 2020 Allrights Reserved By <a href="index.php">Angkatan 2020</a></p>
                </div>
            </div>
        </div>
    </div>
  </footer>

<script src="bootstrap/js/bootstrap.js"></script>
<script src="bootstrap/js/jquery.min.js"></script>
<script src="bootstrap/js/popper.min.js"></script>
<script src="js1/jquery-3.3.1.min.js"></script>
<script src="js1/jquery-ui.js"></script>
<script src="js1/popper.min.js"></script>
<script src="js1/bootstrap.min.js"></script>
<script src="js1/jquery.countdown.min.js"></script>
<script src="js1/jquery.easing.1.3.js"></script>
<script src="js1/aos.js"></script>
<script src="js1/jquery.fancybox.min.js"></script>
<script src="js1/jquery.sticky.js"></script>
<script src="js1/isotope.pkgd.min.js"></script>
<script src="js1/main.js"></script>
</body>
</html>