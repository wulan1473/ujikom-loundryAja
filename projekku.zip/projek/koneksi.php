<?php 

$nama_host          ='localhost';
$username           ='root';
$password           ='';
$nama_db            ='laundry';

$koneksi = mysqli_connect($nama_host,$username,$password,$nama_db);

?>
