<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>halaman ubah paket</title>

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <style>
    body{
        background: #eee;
    }
    .form-login{
        margin-top: 13%;
        margin-left: 30%;
    }
    .outer-form-login{
        padding: 20px;
        background: #eeeeee;
        position: relative;
        border-radius: 5px;
    }

    .inner-login .form-control{
        background: #D3d3d3;
    }
    h3.title-login{
        font-size: 20px;
        margin-bottom: 20px;
    }
    .btn-custom-green{
        background:#21a957;
        color:#fff;
    }

        
    </style>
</head>
<body>
<div class="col-md-4 col-md-offset-4 form-login">
    <div class="outter-form-login">

        <form action="proses_/proses_ubah_paket.php" class="inner-login" method="POST">
        <h3 class="text-center title-login">Ubah Paket</h3>
        <?php
            include "db.php";

            $id     =$_GET['id'];

            $db = new Database();
            $data = $db->getById('paket',['id_paket' => $id]);

            foreach($data as $d):
        ?>
 
        
            <div class="form-group">
                <input class="form-control" name="id_paket" type="name" value="<?php echo $d['id_paket']; ?>" readonly>
            </div>
            <div class="form-group">
                <input class="form-control" name="id_outlet" type="name" value="<?php echo $d['id_outlet']; ?>" readonly>
            </div>
            <div class="form-group">
                <select name="jenis_paket" class="form-group" >
                    <option value="kiloan">Kiloan</option>
                    <option value="selimut">Selimut</option>
                    <option value="bed_cover">Bed cover</option>
                    <option value="kaos">Kaos</option>
                    <option value="lain_lain">Lain-lain</option>
                </select>
            </div>
            <div class="form-group">
                <input class="form-control" name="nama_paket" type="name" value="<?php echo $d['nama_paket']; ?>" required>
            </div>
            <div class="form-group">
                <input class="form-control" name="harga" type="name" value="<?php echo $d['harga']; ?>" required>
            </div>
                <input type="submit" class="btn btn-block btn-custom-green" value="Ubah">
                <?php endforeach; ?>
        </form>
    </div>
</div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>