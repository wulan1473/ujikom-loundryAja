<?php

require '../db.php';

$db = new Database();

$nama   =   $_POST ['nama'];
$alamat =   $_POST ['alamat'];
$telp   =   $_POST ['telp'];

$insert = $db->insert('outlet', [
    'id_outlet' => '',
    'nama'      => $_POST ['nama'],
    'alamat'    => $_POST ['alamat'],
    'telp'      => $_POST ['telp']
]);
if ( $insert > 0 ) {
    echo "Data berhasil dimasukkan";
    header ('location:../outlet.php');
} else {
    echo mysqli_error($db->connect());
}