<?php

require '../db.php';

$db = new Database();

$nama            =   $_POST ['nama'];
$alamat          =   $_POST ['alamat'];
$jenis_kelamin   =   $_POST ['jenis_kelamin'];
$no_telp         =   $_POST ['telepon'];

$insert = $db->insert('member', [
    'id_member' => '',
    'nama'           => $nama,
    'alamat'         => $alamat,
    'jenis_kelamin'  => $jenis_kelamin,
    'no_telp'        => $no_telp
]);
if ( $insert > 0 ) {
    echo "Data berhasil dimasukkan";
    header ('location:../member.php');
} else {
    echo mysqli_error($db->connect());
}