<?php
require '../db.php';

$paket = new Database();

$id_outlet        =$_POST['id_outlet'];
$jenis      =$_POST['jenis'];
$nama       =$_POST['nama_paket'];
$harga      =$_POST['harga'];


$insert = $paket->insert('paket', [
    'id_paket'  => '',
    'id_outlet' => $id_outlet,
    'jenis'  => $jenis,
    'nama_paket' => $nama,
    'harga'     => $harga
]);


if ( $insert > 0 ) {
    header('Location:../paket.php');
} else {
    echo "Gagal..:(";
}

// require '../db.php';

// $db = new Database();

// $id              =   $_POST['id_outlet'];
// $nama_paket      =   $_POST['nama_paket'];
// $jenis           =   $_POST['jenis'];
// $harga           =   $_POST['harga'];

// $insert = $db->insert('paket', [
//     'id_paket'       => '',
//     'id_outlet'      => $id,
//     'jenis'          => $jenis,
//     'nama_paket'     => $nama_paket,
//     'harga'          => $harga
// ]);
// if ( $insert > 0 ) {
//     echo "Data berhasil dimasukkan";
//     header ('location:../paket.php');
// } else {
//     echo mysqli_error($db->connect());
// }
?>