<?php

require '../db.php';

$id=$_GET['id'];

$db = new Database();
$delete = $db->delete('member', ['id_member' => $id]);

if ( $delete > 0 ) {
    // Data berhasil dihapus
    echo "Data berhasil dihapus";
    header ('Location:../member.php');

} else {
    echo mysqli_error($db->connect());
}