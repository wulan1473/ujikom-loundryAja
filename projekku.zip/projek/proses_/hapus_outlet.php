<?php

require '../db.php';

$id=$_GET['id'];

$db = new Database();
$delete = $db->delete('outlet', ['id_outlet' => $id]);

if ( $delete > 0 ) {
    // Data berhasil dihapus
    echo "Data berhasil dihapus";
    header ('Location:../outlet.php');

} else {
    echo mysqli_error($db->connect());
}