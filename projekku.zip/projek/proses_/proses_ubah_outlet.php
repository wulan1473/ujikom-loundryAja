<?php

require '../db.php';

$id     = $_POST['id'];
$nama   =   $_POST ['nama'];
$alamat =   $_POST ['alamat'];
$telp   =   $_POST ['telepon'];

$db = new Database();

$update = $db->update('outlet', [
    'nama'      =>  $nama,
    'alamat'    =>  $alamat,
    'telepon'      =>  $telp,
], ['id_outlet' => $id]);

if ( $update > 0 ) {
    // Data berhasil diubah
    echo "Data berhasil diubah";
    header ('Location:../outlet.php');
} else {
    echo mysqli_error($db->connect());
}