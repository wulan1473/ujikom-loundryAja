<?php

require '../db.php';

$id = $_POST['id'];

$nama            =   $_POST ['nama'];
$alamat          =   $_POST ['alamat'];
$jenis_kelamin   =   $_POST ['jenis_kelamin'];
$no_telpon       =   $_POST ['telepon'];

$db = new Database();
$update = $db->update('member', [
    'nama'               => $_POST['nama'],
    'alamat'             => $_POST['alamat'],
    'jenis_kelamin'      => $_POST['jenis_kelamin'],
    'telepon'          => $_POST['telepon']
], ['id_member' => $id]);

if ( $update > 0 ) {
    echo "Data berhasil diubah";
    header('location:../member.php');
} else {
    echo mysqli_error($db->connect());
}