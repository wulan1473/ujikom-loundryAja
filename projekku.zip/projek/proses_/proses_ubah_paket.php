<?php

require '../db.php';

$id_paket       = $_POST['id_paket'];
$id              =   $_POST ['id_outlet'];
$jenis           =   $_POST ['jenis_paket'];
$nama_paket      =   $_POST ['nama_paket'];
$harga       =   $_POST ['harga'];

$db = new Database();
$update = $db->update('paket', [
    'id_paket'      => '',
    'id_outlet'      => $id,
    'jenis_paket'    => $jenis,
    'nama_paket'     => $nama_paket,
    'harga'          => $harga
], ['id_paket' => $id]);

if ( $update > 0 ) {
    echo "Data berhasil diubah";
    header('location:../paket.php');
} else {
    echo "Gagal".mysqli_error($db->connect());
}
// var_dump($update);die;