<!doctype html>
<html lang="en">

<head>
  <title>Hello, world!</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
</head>

<body>
  <div class="wrapper ">
    <div class="sidebar" data-color="purple" data-background-color="white">
      <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-normal">
          Laundry Aja
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link bg-dark" href="#0">
              <i class="material-icons">dashboard</i>
              <p>Transaksi</p>
            </a>
          </li>
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper" style="">
            <a class="navbar-brand" href="javascript:;">Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="javascript:;">
                  <i class="material-icons">notifications</i> Notifications
                </a>
              </li>
              <!-- your navbar here -->
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <!-- your content here -->
          <!doctype html>
<html lang="en">

<head>
  <title>Hello, world!</title>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- Material Kit CSS -->
  <link href="assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
</head>

<body>
  <div class="wrapper ">
    <div class="sidebar" data-color="black" data-background-color="white">
      <!--
      Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

      Tip 2: you can also add an image using data-image tag
  -->
      <div class="logo">
        <a href="http://www.creative-tim.com" class="simple-text logo-normal">
          Laundry Aja
        </a>
      </div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link bg-dark" href="#0">
              <i class="material-icons">dashboard</i>
              <p>Transaksi</p>
            </a>
          </li>
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper" style="">
            <a class="navbar-brand" href="javascript:;">Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a class="nav-link" href="javascript:;">
                  <i class="material-icons">notifications</i> Notifications
                </a>
              </li>
              <!-- your navbar here -->
            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
          <!-- your content here -->
          <div class="container">
<form class="form" action="proses_transaksi.php" method="POST">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label> Id Outlet </label>
        <?php 
        $id   = $_GET['id'];
        require '../db.php';
        $db = new Database();
        
        $query = mysqli_query($db->connect(), "SELECT * FROM paket INNER JOIN outlet ON paket.id_outlet=outlet.id_outlet WHERE paket.id_paket='$id'");
        while ($out = mysqli_fetch_array($query, MYSQLI_ASSOC)):
        ?>
        <input type="text" name="id_outlet" class="form-control" value="<?= $out['id_outlet']; ?>" >
        <?php endwhile; ?>
    </div>
    <div class="form-group col-md-6">
      <label> Nama Member </label>
      <select name="id_member" class="form-control">
        <?php 
        $db = new Database();
        $member = $db->getAll('member');
        foreach($member as $mem):
        ?>
        <option value="<?= $mem['id_member']; ?>" class="form-control"> <?= $mem['nama']; ?> </option> 
        <?php endforeach; ?>
        </select>
    </div>
  </div>
  <div class="form-row">
  <div class="form-group col-md-6">
    <label> Nama Paket </label>
    <?php 
    $id   =$_GET['id'];
    $db = new Database();
        $paket = $db->getById('paket', ['id_paket' => $id]);
        foreach($paket as $pak):
        ?>
    <input type="text" name="id_paket" class="form-control" value="<?= $pak['nama_paket']; ?>">
    <?php endforeach; ?>
  </div>
  <div class="form-group col-md-6">
    <label> Harga </label>
    <?php 
        $idku   =$_GET['id'];
        $db = new Database();
        $harga = $db->getById('paket', ['id_paket' => $idku]);
        foreach($harga as $har):
        ?>
    <input type="text" name="harga" id="harga" class="form-control" value="<?= $har['harga']; ?>" onkeyup="sum();" readonly >
    <?php endforeach; ?>
  </div>
  </div>
  <div class="form-row">
  <div class="form-group col-md-6">
      <label> Id Transaksi </label>
      <input type="text" class="form-control" name="id_transaksi" value="<?php echo(rand()); ?>" readonly>
    </div>
  <div class="form-group col-md-6">
      <label> Jumlah </label>
      <input type="number" id="jumlah" class="form-control" name="jumlah" placeholder="Masukan Jumlah" onkeyup="sum();">
    </div>
    </div> 
    <div class="form-row">
    <div class="form-group col-md-6">
      <label> Tanggal </label>
      <input type="date" class="form-control" name="tanggal">
    </div>
    <div class="form-group col-md-6">
      <label> Deadline </label>
      <input type="date" class="form-control" name="batas_waktu" placeholder="Deadline">
    </div>
    </div> 
    <div class="form-row">
  <div class="form-group col-md-6">
    <label> Tanggal Bayar </label>
    <input type="date" class="form-control" name="tgl_bayar" placeholder="Tanggal Bayar ">
  </div>
  <div class="form-group col-md-6">
    <label> Biaya Tambahan </label>
    <input type="text" name="biaya_tambahan" class="form-control" id="biaya" onkeyup="sum();" value="5000" readonly >
  </div>
  </div> 
  <div class="form-row">
    <div class="form-group col-md-6">
      <label> Discount </label>
      <input type="text" name="diskon" class="form-control" id="inputCity">
    </div> 
    <div class="form-group col-md-6">
      <label> Pajak </label>
      <input type="text" name="pajak" class="form-control" value="3000" id="pajak" readonly>
    </div>
    </div> 
    <div class="form-row">
    <div class="form-group col-md-6">
      <label> Status Transaksi </label>
      <select name="status" class="form-control">
      <option selected> Pilih </option>
      <option value="baru"> Baru </option>
      <option value="proses"> Sedang Proses</option>
      <option value="dibayar"> Selesai </option>
      <option value="diambil"> Diambil / Diantar </option>
      </select>
    </div>
    <div class="form-group col-md-4">
      <label> Pembayaran </label>
      <select name="pembayaran" class="form-control">
        <option selected> Pilih </option>
        <option value="dibayar"> Dibayar </option>
        <option value="belum_dibayar"> Belum Dibayar </option>
      </select>
    </div> 
    </div> 
    <div class="form-row">
    <div class="form-group col-md-4">
      <label for="inputState"> Penanggung Jawab Member </label>
      <select name="id_user" class="form-control">
        <?php 
        $db = new Database();
        $user = $db->getAll('user');
        foreach($user as $use):
        ?>
        <option value="<?= $use['id_user']; ?>" class="form-control"> <?= $use['nama']; ?> </option> 
        <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group col-md-6">
    <label> Kode Invoice </label>
    <input type="text" name="kode_invoice" class="form-control" value="<?php echo(rand()); ?>" >
  </div>
  </div> 
  <div class="form-row" >
  <div class="form-group col-md-6">
    <label> Total Harga </label>
    <input type="text" name="total_harga" class="form-control" id="total_harga" >
    <script>
function sum() {
      var txtFirstNumberValue = document.getElementById('harga').value;
      var txtSecondNumberValue = document.getElementById('jumlah').value;
      var txtThirdNumberValue = document.getElementById('biaya').value;
      var txtFourthNumberValue = document.getElementById('pajak').value;
      var result = parseFloat(txtFirstNumberValue) * parseFloat(txtSecondNumberValue)+ parseFloat(txtThirdNumberValue) + parseFloat(txtFourthNumberValue);
      if (!isNaN(result)) {
         document.getElementById('total_harga').value = result;
      }
}
</script>
  </div>
  <div class="form-group col-md-6">
    <label> Keterangan </label>
    <input type="text" name="keterangan" class="form-control" >
  </div>
    </div>
    <br> <br>
  <button type="submit" name="bayar" class="btn btn-primary" style="background-color:black;"> Masukan </button>
</form>
</div> 


        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href="https://www.creative-tim.com">
                  Creative Tim
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a> for a better web.
          </div>
          <!-- your footer here -->
        </div>
      </footer>
    </div>
  </div>
</body>

</html>


        </div>
      </div>
      <footer class="footer">
        <div class="container-fluid">
          <nav class="float-left">
            <ul>
              <li>
                <a href="https://www.creative-tim.com">
                  Creative Tim
                </a>
              </li>
            </ul>
          </nav>
          <div class="copyright float-right">
            &copy;
            <script>
              document.write(new Date().getFullYear())
            </script>, made with <i class="material-icons">favorite</i> by
            <a href="https://www.creative-tim.com" target="_blank">Creative Tim</a> for a better web.
          </div>
          <!-- your footer here -->
        </div>
      </footer>
    </div>
  </div>
</body>

</html>