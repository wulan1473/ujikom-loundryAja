<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>halaman login</title>

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    
    <style>
    body{
        background: #eee;
    }
    .form-login{
        margin-top: 13%;
        margin-left: 30%;
    }
    .outer-form-login{
        padding: 20px;
        background: #eeeeee;
        position: relative;
        border-radius: 5px;
    }

    .inner-login .form-control{
        background: #D3d3d3;
    }
    h3.title-login{
        font-size: 20px;
        margin-bottom: 20px;
    }
    .btn-custom-green{
        background:#21a957;
        color:#fff;
    }

        
    </style>
</head>
<body>
<div class="container">
<form action="proses_login.php" METHOD="POST">
    <h2 class="text-center"> SILAHKAN LOGIN </h2>
    <hr>
        <div class="form-group">
        <label> Username </label>
        <input type="text" name="username" class="form-control" placeholder="Username" required>
        <br>
        </div>
        <label> Password </label>
        <input type="password" name="password" class="form-control" placeholder="Password" required>
        <br>
        <br>
        <button type="submit" name="login" class="btn btn-primary"> Login </button>
        <button type="reset" class="btn btn-danger"> Reset </button>
        
    </form>
    </div>

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>

</body>
</html>