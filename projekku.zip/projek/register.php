
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>halaman tambah member</title>

    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <style>
    body{
        background: #eee;
    }
    .form-login{
        margin-top: 13%;
        margin-left: 30%;
    }
    .outer-form-login{
        padding: 20px;
        background: #eeeeee;
        position: relative;
        border-radius: 5px;
    }

    .inner-login .form-control{
        background: #D3d3d3;
    }
    h3.title-login{
        font-size: 20px;
        margin-bottom: 20px;
    }
    .btn-custom-green{
        background:#21a957;
        color:#fff;
    }

        
    </style>
</head>
<body>
<div class="container">
<form action="proses_register.php" METHOD="POST">
    <h2 class="text-center"> Masukan Member Baru </h2>
        <hr>
        <label>Nama</label>
        <input type="text" name="nama" class="form-control" placeholder="Nama" required>
        <br> <br>
        <label> Alamat </label>
        <textarea name="alamat" class="form-control" id="" cols="30" rows="10"></textarea>
        <br> <br>
        <label> Jenis Kelamin </label>
        <select name="jenis_kelamin" id="" style="width: 30%; margin-left: 7.5cm;">
        <option value="L"> Laki-Laki </option>
        <option value="P"> Perempuan </option>
        </select>
        <br> <br>
        <label> Telephone </label>
        <input type="text" name ="telp" class="form-control" placeholder="Telephone" required>
        <br> <br>
        <button type="submit" class="btn btn-primary">
         Masukan
        </button>
        </form>
        </div>
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
</body>
</html>